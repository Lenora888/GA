


	function changeImage(newId){
		var newsrc = document.getElementById(newId).src;
		var largeimg = document.getElementById("bigimg");
		largeimg.src=newsrc;
	}


